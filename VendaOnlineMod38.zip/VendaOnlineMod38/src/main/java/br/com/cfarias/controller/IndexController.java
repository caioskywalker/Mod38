package br.com.cfarias.controller;

public class IndexController {

}
