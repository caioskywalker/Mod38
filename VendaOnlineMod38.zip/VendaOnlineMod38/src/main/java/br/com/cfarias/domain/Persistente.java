package br.com.cfarias.domain;

public interface Persistente {

	public Long getId();
	
	public void setId(Long id);
	
	
	
}
